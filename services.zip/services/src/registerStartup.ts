import { Observable } from "rxjs";
import { serviceManagerInstance } from "./instance";
import { logService } from "./LogService";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type ServiceType<T> = new(...args: any[]) => T;

/**
 * Interface which is invoked during a service startup.
 */
export interface OnStartup {
	onStartup(): Observable<unknown> | unknown | undefined | void;
}

/**
 * Registers a startup service, meaning it holds rendering of the children until
 * it has finished initializing.
 * 
 * @param startupService The service to register a startup service, needs to inherit from OnStartup
 */
export function registerStartup<T extends OnStartup>(startupService: ServiceType<T>) {
	logService.log('Registering startup service "{0}"', startupService.name);
	return serviceManagerInstance.registerStartup(startupService);
}