import { serviceManagerInstance } from "./instance";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type ServiceType<T> = new(...args: any[]) => T;

export function getService<T>(service: ServiceType<T>) {
	return serviceManagerInstance.get<T, T>(service);
}