import { ServiceManager } from "./ServiceManager";

const serviceManagerInstance = new ServiceManager();
export { serviceManagerInstance }