import { render } from '@testing-library/react';

import LogView from './LogView';

describe('LogView', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<LogView />);
    expect(baseElement).toBeTruthy();
  });
});
