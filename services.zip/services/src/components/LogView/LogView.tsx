import styles from './LogView.module.css';
import { useService } from '../../useService';
import { LogService, LogEntry } from '../../LogService';
import { MouseEventHandler, useEffect, useState } from 'react';
import { Http2SecureServer } from 'node:http2';
import clsx from 'clsx';
import { takeLast } from 'rxjs/operators';

/* eslint-disable-next-line */
export interface LogViewProps {}

export function LogView(props: LogViewProps) {
  const [entries, setEntries] = useState<LogEntry[]>([])
  const [minimize, setMinimize] = useState(false);
  const logService = useService(LogService);

  useEffect(() => {
    const subscription = logService.messages.subscribe(
      (entries) => {
        setTimeout(() => setEntries(entries), 0);
      }
    );
    return () => subscription.unsubscribe();
  });

  const toggle: MouseEventHandler<HTMLDivElement> = (event) => {
    console.log("toggle minimize", minimize);
    setMinimize(!minimize);
  }

  return (
    <div className={styles.logView}>
      <div className={clsx({
          [styles.header]: true,
          [styles.miniHeader]: minimize
      })} onClick={toggle}>
        HHF Log
      </div>
      <div className={clsx({
        [styles.view]: true,
        [styles.miniView]: minimize
      })}>
        {entries.map((entry) => (
          <div key={entry.text} className={styles[entry.level]}>{entry.text}</div>
        ))}
      </div>
    </div>
  );
}

export default LogView;
