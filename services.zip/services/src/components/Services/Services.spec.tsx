import { render, screen } from '@testing-library/react';
import Services from './Services';

describe('Services', () => {
  it('Should render the fallback when provided', () => {
    render(<Services fallback={<div>fallback</div>}/>);
    expect(screen.getByText("fallback")).toBeTruthy();
  });

  it('Should render nothing when no fallback is provided', () => {
    const { baseElement } = render(<Services />);
    expect(baseElement.textContent).toBeFalsy();
  });
});
