import { ComponentType, isValidElement, PropsWithChildren, useEffect, useState } from 'react';
import { serviceManagerInstance } from '../../instance';

/* eslint-disable-next-line */
export interface ServicesProps {
  fallback?: JSX.Element
}

export function Services({ fallback, children }: PropsWithChildren<ServicesProps>) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const subscription = serviceManagerInstance.startup().subscribe({
      next: () => {
        console.log("reveal children");
        setReady(true)
      },
      error: (error) => {
        console.error("Unable to initialize services:", error);
        setReady(false);
      }
    });

    return () => {
      subscription.unsubscribe();
      serviceManagerInstance.shutdown();
    }
  }, []);

  if (!ready) {
    return isValidElement(fallback) ? fallback : null;
  }

  return (
    // eslint-disable-next-line react/jsx-no-useless-fragment
    <>
      {children}
    </>
  );
}

export default Services;
