import { logService } from "../LogService";
import { ConfigService } from "./ConfigService";
import fetchMock from "jest-fetch-mock";

const mock = {
	production: false,
	valueOne: "value-one",
	objectTwo: {
		valueTwo: "value-two"
	}
}

fetchMock.enableMocks();

describe("ConfigService", () => {
	let configService: ConfigService;

	beforeEach(() => {
		fetchMock.resetMocks();
		configService = new ConfigService(logService);
	});

	it('Should be able to be created', () =>{
		expect(configService).toBeInstanceOf(ConfigService);
	});
	
	it('Should accept an environment', () => {
		configService.setEnvironment(mock);
		expect(configService.get("production")).toEqual(false);
	});

	it('Should expose development mode', () => {
		configService.setEnvironment(mock);
		expect(configService.isProduction).toBe(false);
		expect(configService.isDevelopment).toBe(true);
	});

	it('Should expose production mode', () => {
		configService.setEnvironment(Object.assign({}, mock, { production: true }));
		expect(configService.isProduction).toBe(true);
		expect(configService.isDevelopment).toBe(false);
	});

	it('Should match values with a string path', () => {
		configService.setEnvironment(mock);
		expect(configService.get("objectTwo.valueTwo")).toBe("value-two");
	});

	it('Should match a value with an array path', () => {
		configService.setEnvironment(mock);
		expect(configService.get(["objectTwo", "valueTwo"])).toBe("value-two");
	});

	it('Should return the default value when not present', () => {
		expect(configService.get("notFound", 11)).toBe(11);
	});

	it('Uses the config values from the server', done => {
		fetchMock.mockResponseOnce(JSON.stringify({ serviceValue: 'server-value' }));
		configService.setEnvironment(Object.assign({}, mock, { production: true }));
		configService.onStartup().subscribe(
			() => {
				try {
					expect(configService.get("serviceValue")).toBe("server-value");
					done();
				} catch (e) {
					done(e);
				}
			}
		)
	});
/*
	it('checks two configs in development mode', done => {
		fetchMock.mockResponse(() => JSON.stringify{ ok: false });
		configService.setEnvironment(mock);
		configService.onStartup().subscribe(
			() => {
				try {
					expect(fetch).toHaveBeenCalledTimes(2);
					done();
				} catch (e) {
					done(e);
				}
			}
		)
	})*/
});