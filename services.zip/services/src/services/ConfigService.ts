/* eslint-disable @typescript-eslint/no-explicit-any */
import { LogService } from "../LogService";
import { OnStartup } from "../registerStartup";
import get from 'lodash/get';
import { from, Observable, of } from "rxjs";
import { catchError, switchMap, tap } from "rxjs/operators";

interface WithProduction {
	production: boolean;
}

/**
 * 
 */
export class ConfigService implements OnStartup {
	static Dependencies = [LogService];
	private _config: WithProduction & Record<string, unknown> = { production: false };
	private _isProduction = false;

	constructor(
		private _log: LogService
	){}

	/**
	 * Set the starting environment, this should include at a minimum the production flag
	 * which controls where we look online for the config service.
	 * 
	 * @param environment The environment to start with
	 */
	setEnvironment(environment: WithProduction) {
		this._config = Object.assign({}, environment) as any;
		this._isProduction = (this._config.production === true);
	}

	/**	Retrieve the current production state */
	get isProduction() {
		return this._isProduction;
	}

	/**	Retreive the current development state */
	get isDevelopment() {
		return !this._isProduction;
	}

	/**
	 * Fetch a value form the configuration
	 * 
	 * @param path The path either a string or an array of strings
	 * @param defaultValue The default value to return if not found
	 * @returns The value from the environment or the default
	 */
	get(path: string | string[], defaultValue?: any) {
		const configValue = get(this._config, path);
		if (configValue === undefined) {
			return defaultValue;
		}

		return configValue;
	}

	/**
	 * Handle the startup, check if we have server/asset overrides
	 */
	onStartup(): Observable<unknown> {
		if (!this.isProduction) {
			let url = '/assets/config.development.json';
			return from(fetch('/assets/config.development.json')).pipe(
				switchMap(
					response => {
						if (response.ok) { 
							return from(response.json())
						} else {
							url = '/assets/config.json';
							return from(fetch('/assets/config.json')).pipe(
								switchMap(response => 
										response.ok ? 
										from(response.json()) : 
										of(null)
									)
								);
						}
					}
				),
				catchError(() => of(null)),
				tap(config => {
					if (config !== null) {
						this._log.log("Applying configuration from the server '{0}'", url)
						Object.assign(this._config, config)
					}
				})
			)
		} else {
			return from(fetch('/assets/config.json')).pipe(
				switchMap(
					response => from(response.json())
				),
				catchError(() => of(null)),
				tap(config => { 
					if (config !== null) {
						this._log.log('Applying configuration from the service "/assets/config.json"');
						Object.assign(this._config, config)
					}
				})
			);
		}
	}

}